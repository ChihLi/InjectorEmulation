### from MBESS
cov2cor <- function (V)
{
  p <- (d <- dim(V))[1L]
  if (!is.numeric(V) || length(d) != 2L || p != d[2L])
    stop("'V' is not a square numeric matrix")
  Is <- sqrt(1/diag(V))
  if (any(!is.finite(Is)))
    warning("diag(.) had 0 or NA entries; non-finite result is doubtful")
  r <- V
  r[] <- Is * V * rep(Is, each = p)
  r[cbind(1L:p, 1L:p)] <- 1
  r
}
