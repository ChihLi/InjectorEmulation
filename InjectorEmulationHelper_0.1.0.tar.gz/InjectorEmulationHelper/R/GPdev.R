#' Deviation for Gaussian Process
#'
#' @export
#'

GPdev <- function(corr, xMat, yMat, pw=2){
  #   corr <- allPar[which.min(allVal),]

  #See sourceCpp function for parameter details
  n <- nrow(xMat)

  #if correlation matrix is sigular, then return Inf (edited on 07/27/2016)
  #Inf is not able to proceed the function "lbfgs" so I use 1e10 (sufficiently large) instead
  R <- computeR(corr, xMat, yMat, pw)
  if(det(R) < 1e-30) return(1e10)

  #Update parameters
  params <- computeS(corr, xMat, yMat, pw);   #params[1] - mu, params[2] - Rinv, params[3] - data matrix for T

  #Testing as independent kriging
  vars = apply(params$Rsd,2,function(xx){mean(xx^2)}) #Adjust by variance
  if (length(vars)==1){
    Tinv = matrix(1/vars, ncol=1, nrow=1)
  }else{
    Tinv = diag(1/vars)
  }

  #Compute deviance
  #   dim(yMat)
  ret = computeDev(c(params$mu), params$Rinv, corr, yMat, Tinv, 1) #1 indicates indep
  #   print(ret)
  return(ret)
}
